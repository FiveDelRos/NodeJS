modules.export = {
  "<" : "<", //tag start
  ">" : ">", //tag end
  "/" : "/", //close tag
  "!" : "!", //comment or docttype
  "!--" : "!--", //comment
  "-->" : "-->", //comment end
  "?" : "?", //pi
  "?>" : "?>", //pi end
  "?xml" : "?xml", //pi end
  "![" : "![", //cdata
  "]]>" : "]]>", //cdata end
  "[" : "[",
  "-" : "-",
  "D" : "D",
}