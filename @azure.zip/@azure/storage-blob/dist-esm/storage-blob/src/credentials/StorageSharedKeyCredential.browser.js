// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
export class StorageSharedKeyCredential {
}
//# sourceMappingURL=StorageSharedKeyCredential.browser.js.map