// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
export class UserDelegationKeyCredential {
}
//# sourceMappingURL=UserDelegationKeyCredential.browser.js.map