// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
export { AvroReader } from "./AvroReader";
export { AvroReadable } from "./AvroReadable";
export { AvroReadableFromBlob } from "./AvroReadableFromBlob";
//# sourceMappingURL=index.browser.js.map