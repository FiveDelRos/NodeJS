// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
export class AvroReadable {
}
//# sourceMappingURL=AvroReadable.js.map