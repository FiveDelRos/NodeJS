// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
// This file is used as a shim of "BufferScheduler" for some browser bundlers
// when trying to bundle "BufferScheduler"
// "BufferScheduler" class is only available in Node.js runtime
export class BufferScheduler {
}
//# sourceMappingURL=BufferScheduler.browser.js.map