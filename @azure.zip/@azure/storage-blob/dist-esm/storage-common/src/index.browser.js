// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
export * from "./BufferScheduler.browser";
//# sourceMappingURL=index.browser.js.map